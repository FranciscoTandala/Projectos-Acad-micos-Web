let contador = 1; // Começa em 1

// Atualiza o número na tela
function atualizarDisplay() {
  document.getElementById('valor').innerText = contador;
}

function aumentar() {
  if (contador < 10) {
    contador++;
    atualizarDisplay();
  }
}

function diminuir() {
  if (contador > 1) {
    contador--;
    atualizarDisplay();
  }
}

// Atualiza o display assim que a página carrega
window.onload = atualizarDispla